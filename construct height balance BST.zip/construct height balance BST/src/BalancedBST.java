//Construct height balance BST
import java.util.Arrays;

public class BalancedBST {
    private static class Node {
        int data;
        Node left, right;

        public Node(int data) {
            this.data = data;
        }
    }

    private Node root;

    public BalancedBST() {
        root = null;
    }

    public void constructBalancedBST(int[] keys) {
        // Sort the keys in ascending order
        Arrays.sort(keys);

        // Construct the balanced BST
        root = constructBalancedBST(keys, 0, keys.length - 1);
    }

    private Node constructBalancedBST(int[] keys, int start, int end) {
        // Base case: if the start index is greater than the end index, return null
        if (start > end) {
            return null;
        }

        // Calculate the middle index
        int mid = start + (end - start) / 2;

        // Create a new node with the middle key
        Node node = new Node(keys[mid]);

        // Recursively construct the left and right subtrees
        node.left = constructBalancedBST(keys, start, mid - 1);
        node.right = constructBalancedBST(keys, mid + 1, end);

        // Return the node
        return node;
    }

    public void printInorder() {
        printInorder(root);
    }

    private void printInorder(Node root) {
        if (root != null) {
            printInorder(root.left);
            System.out.print(root.data + " ");
            printInorder(root.right);
        }
    }

    public static void main(String[] args) {
        // Create a sample array of keys
        int[] keys = {15, 10, 20, 8, 12, 16, 25};

        BalancedBST balancedBST = new BalancedBST();

        // Construct the balanced BST
        balancedBST.constructBalancedBST(keys);

        // Print the inorder traversal of the balanced BST
        System.out.println("Inorder traversal of the balanced BST:");
        balancedBST.printInorder();
    }
}
//The difference between the author and my solution is that the parameters that the author used more often than mine
//because I coded into a basic type of field because I have use the array class in this code which I manage somehow
//find ways how to use to make the code much shorter. As the author's code was more functional because he created
//various methods to execute the height itself well, and also readable, rather than mine hard coded with less method
//if it will execute into a different kind of nodes here the author's had more functionality, but still manage to create one.