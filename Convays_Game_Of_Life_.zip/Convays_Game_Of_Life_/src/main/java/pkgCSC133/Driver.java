package pkgCSC133;

import pkgAURenderEngine.AURenderer;
import pkgAUUtils.AUPingPongArray;
import pkgAUUtils.AUGoLArray;
import pkgAUUtils.AUWindowManager;

public class Driver {
    public static void main(String[] my_args) {
        int numRows = 200, numCols = 200;
        int winOrgX = 20, winOrgY = 50, polyLength = 4, polyOffset = 10, polyPadding = 1;
        AUGoLArray goLArray;// = new AUGoLArray(numRows, numCols, (int) (0.2*numRows*numCols+0.5));
        if(my_args.length != 0){// If the text file is given
            goLArray = new AUGoLArray(my_args[0]);
            numRows = 16;
            numCols = 16;
            polyLength = 40;
            polyOffset = 20;
            polyPadding = 20;
            winOrgX = 50;
            winOrgY = 50;
        }
        else{
            goLArray = new AUGoLArray(numRows, numCols, (int) (0.2*numRows*numCols+0.5));
        }
        goLArray.swapLiveAndNext();
        final int winWidth = (polyLength + polyPadding) * numCols + 2 * polyOffset;
        final int winHeight = (polyLength + polyPadding) * numRows + 2 * polyOffset;
        final AUWindowManager myWM = AUWindowManager.get(winWidth, winHeight, winOrgX, winOrgY);
        final AURenderer myRenderer = new AURenderer(myWM, goLArray);
        myRenderer.render(polyOffset, polyPadding, polyLength, numRows, numCols);
    }  //  public static void main(String[] my_args)
}  //  public class Driver




