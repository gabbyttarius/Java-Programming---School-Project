package pkgAUUtils;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class AUPingPongArray {
    private int degree = 1;
    private int numRows;
    private int numCols;
    private int randMin;
    private int randMax;
    private int defaultValue = 0;
    private int[][] liveArray, nextArray;
    private Random random = new Random();
    public AUPingPongArray(final int numRows, final int numCols, final int randMin, final int randMax){
        this.numRows = numRows;
        this.numCols = numCols;
        this.randMin = randMin;
        this.randMax = randMax;
        liveArray = new int[numRows][numCols];
        nextArray = new int[numRows][numCols];
        randomizeInRange();
    }

    protected record RCPair<row, col>(int row, int col){}

    public void swapLiveAndNext(){
        int[][] temp = liveArray;
        liveArray = nextArray;
        nextArray = temp;
    }

    public void printArray(){
        for(int row = 0; row < numRows; row++){
            System.out.print(row + "  ");
            for(int col = 0; col < numCols; col++){
                System.out.print(" " + liveArray[row][col]);
            }
            System.out.println();
        }
    }

    public void printNextArray(){
        for(int row = 0; row < numRows; row++){
            System.out.print(row + "  ");
            for(int col = 0; col < numCols; col++){
                System.out.print(" " + nextArray[row][col]);
            }
            System.out.println();
        }
    }

    public void setCell(final int row, final int col, final int newValue){
        nextArray[row][col] = newValue;
    }

    public void randomizeViaFisherYatesKnuth(){
        copyToNextArray();//nextArray = liveArray.clone();//nextArray = getArray();
        int totalNumberOfElements = numRows*numCols;
        int counter = 0, temp, randomIndex, randomRow, randomCol;
        for(int row = 0; row < numRows; row++){
            for(int col = 0; col < numCols; col++){
                randomIndex = random.nextInt(counter, totalNumberOfElements);
                randomRow = randomIndex / numCols;
                randomCol = randomIndex % numCols;
                temp = nextArray[randomRow][randomCol];
                setCell(randomRow, randomCol, nextArray[row][col]);
                setCell(row, col, temp);
                counter++;
            }
        }
    }
    //swapLiveAndNext is included in randomizeInRange().
    private void randomizeInRange(){
        int randomNumber = 0;
        for (int row = 0; row < numRows; ++row) {
            for (int col = 0; col < numCols; ++col) {
                randomNumber = random.nextInt(randMin, randMax);
                setCell(row, col, randomNumber);
                //liveArray[row][col] = randomNumber;
            }
        }
        swapLiveAndNext();
        randomizeViaFisherYatesKnuth();
    }

    public void loadFile(final String dataFileName){
        try {
            File file = new File(dataFileName);
            Scanner scanner = new Scanner(file);
            if(scanner.hasNextLine()){
                defaultValue = scanner.nextInt();
            }
            scanner.nextLine();
            if(scanner.hasNextLine()){
                numRows = scanner.nextInt();
                numCols = scanner.nextInt();
            }
            scanner.nextLine();
            //nextArray = new int[numRows][numCols];//fix bug
            //liveArray = new int[numRows][numCols];
            AUPingPongArray myBoard = new AUPingPongArray(numRows, numCols, randMin, randMax);
            myBoard.swapLiveAndNext();
            //...
            //deepCopy(this.liveArray, newBoard.getArray());
            int curRow = 0;
            for (int row = 0; row < numRows; row++) {
                for (int col = 0; col < numCols; col++) {
                    //liveArray[row][col] = defaultValue;
                    //setCell(row, col, defaultValue);
                    myBoard.setCell(row, col, defaultValue);
                }
            }
            while(scanner.hasNextLine()){
                String line = scanner.nextLine();
                int[] readRow = Arrays.stream(line.split("\\s+"))
                        .mapToInt(Integer::parseInt)
                        .toArray();
                curRow = readRow[0];

                for (int curCol = 1; curCol < readRow.length; ++curCol) {
                    //liveArray[curRow][curCol-1] = readRow[curCol];
                    //setCell(curRow, curCol-1, readRow[curCol]);
                    myBoard.setCell(curRow, curCol-1, readRow[curCol]);
                }
            }
            this.liveArray = myBoard.getArray();
            myBoard.swapLiveAndNext();
            this.nextArray = myBoard.getArray();
            //deepCopy(this.nextArray, myBoard.getArray());
        }
        catch(FileNotFoundException e){
            System.out.println("File not found error: " + dataFileName);
        }
    }

    public RCPair[] getNearestNeighborsArray(final int orgRow, final int orgCol){
        RCPair[] rcPair = new RCPair[(int) Math.pow(2, 2+degree)];
        int counter = 0;
        for(int row = 0; row < 2+degree; row++){
            for(int col = 0; col < 2+degree; col++){
                if(row == 1 && col == 1){
                    continue;
                }
                rcPair[counter] = new RCPair((numRows-1+row+orgRow) % numRows, (numCols-1+col+orgCol) % numCols);
                counter++;
            }
        }
        return rcPair;
    }

    public void updateToNearestNNSum(){
        for(int row = 0; row < numRows; row++){
            for(int col = 0; col < numCols; col++){
                int sum =0;
                RCPair[] rcPairs = getNearestNeighborsArray(row, col);
                for(int counter = 0; counter < rcPairs.length; counter++){
                    sum = sum + liveArray[rcPairs[counter].row][rcPairs[counter].col];
                }
                setCell(row, col, sum);
            }
        }
    }

    public void save(final String dataFileName){
        try(FileWriter writer = new FileWriter(dataFileName)){
            writer.write(defaultValue + "\n");
            writer.write(numRows + " " + numCols + "\n");
            for(int row = 0; row < numRows; row++){
                writer.write(row + "  ");
                for(int col = 0; col < numCols; col++){
                    writer.write(liveArray[row][col] + " ");
                }
                writer.write("\n");
            }
            System.out.println("Wrote file: " + dataFileName);
        }
        catch(IOException e){
            System.out.println("File writing error: " + dataFileName);
        }
    }

    public void save(){
        save("ppa_data.txt");
    }//saves in ppa_data.txt

    public int[][] getArray(){
        int[][] array = new int[numRows][numCols];
        deepCopy(array, liveArray);
        return array;
    }
    public void copyToNextArray(){
        deepCopy(nextArray, liveArray);
    }
    public int[][] readFromNextArray(){
        int[][] array = new int[numRows][numCols];
        deepCopy(array, nextArray);
        return array;
    }
    private void deepCopy(int[][] destination, int[][] source){
        if (destination.length != source.length) {
            throw new IllegalArgumentException("Array sizes must match");
        }
        for(int counter = 0; counter < destination.length; counter++){
            destination[counter] = source[counter].clone();
        }
    }
}
