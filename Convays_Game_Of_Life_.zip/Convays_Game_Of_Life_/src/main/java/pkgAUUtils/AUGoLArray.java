package pkgAUUtils;

public class AUGoLArray extends AUPingPongArray{
    private static final int DEAD = 0, LIVE = 1;
    //private int numRows, numCols, numLiveCells;
    //public AUPingPongArray ppa; //= new AUPingPongArray(numRows, numCols, DEAD, LIVE); shouldn't be declared in here or else error
    public AUGoLArray(final String dataFileName){
        super(16, 16, DEAD, LIVE);
        swapLiveAndNext();
        loadFile(dataFileName);
        //swapLiveAndNext(); will be done by the client
    }
    public AUGoLArray(final int numRows, final int numCols){
        super(numRows, numCols, DEAD, LIVE+1);
        //swapLiveAndNext(); will be done by the client
    }
    public AUGoLArray(final int numRows, final int numCols, final int numLiveCells){
        super(numRows, numCols, DEAD, LIVE);//Initialize the PPArray with all dead cells as [0, 1)
        swapLiveAndNext();
        //ppa = new AUPingPongArray(numRows, numCols, DEAD, LIVE);
        //ppa.swapLiveAndNext();
        //this.numRows = numRows;
        //this.numCols = numCols;
        //this.numLiveCells = numLiveCells;
        for(int counter = 0; counter < numLiveCells; counter++){
            int row = counter / numCols;
            int col = counter % numCols;
            super.setCell(row, col, LIVE);
        }
        /*
        for(int row = 0; row < numRows; row++){
            for(int col = 0; col < numCols; col++){
                super.setCell(row, col, DEAD);
            }
        }
        for(int counter = 0; counter < numLiveCells; counter++){
            int row = counter / numCols;
            int col = counter % numCols;
            super.setCell(row, col, LIVE);
        }
        */
        super.swapLiveAndNext();
        super.randomizeViaFisherYatesKnuth();
        //swapLiveAndNext(); will be done by the client
    }
    public int countLiveDegreeTwoNeighbors(final int row, final int col){
        int counter = 0;
        int[][] liveArray = super.getArray();
        for (AUPingPongArray.RCPair rcPair : getNearestNeighborsArray(row, col)) {
            if(liveArray[rcPair.row()][rcPair.col()] == LIVE){
                counter += 1;
            }
        }
        return counter;
    }
    public void onTickUpdate(){
        int[][] liveArray = super.getArray();
        for(int row = 0; row < liveArray.length; row++){
            for(int col = 0; col < liveArray[0].length; col++){
                super.setCell(row, col, DEAD);
            }
        }
        for(int row = 0; row < liveArray.length; row++) {
            for (int col = 0; col < liveArray[0].length; col++) {
                int liveNumCells = countLiveDegreeTwoNeighbors(row, col);
                if(liveNumCells == 3){
                    super.setCell(row, col, LIVE);
                }
                else if(liveNumCells == 2){
                    super.setCell(row, col, liveArray[row][col]);
                }
            }
        }
    }
}
