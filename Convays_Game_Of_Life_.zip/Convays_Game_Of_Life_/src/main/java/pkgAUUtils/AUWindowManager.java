package pkgAUUtils;

import org.lwjgl.glfw.*;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11C.glViewport;
import static org.lwjgl.system.MemoryUtil.NULL;

public class AUWindowManager {
    private static GLFWErrorCallback errorCallback;
    private static GLFWKeyCallback keyCallback;
    private static GLFWFramebufferSizeCallback fbCallback;

    private AUWindowManager(){
        my_window = this;
        initGlfwWindow();
    }
    private static GLFWFramebufferSizeCallback resizeWindow =
            new GLFWFramebufferSizeCallback(){
                @Override
                public void invoke(long window, int width, int height){
                    glViewport(0,0,width, height);
                }
            };
    private static AUWindowManager my_window;
    private static long glfwWindow;
    private static int win_height, win_width, win_orgX = 0, win_orgY = 0;
    public static AUWindowManager get(){
        if (my_window == null){
            my_window = new AUWindowManager();
        }
        return my_window;
    }
    public static AUWindowManager get(int width, int height){
        setWinWidth(width, height);
        if (my_window == null){
            my_window = new AUWindowManager();
        }
        return my_window;
    }
    public static AUWindowManager get(int width, int height, int win_orgX, int win_orgY){
        get(width, height);
        setWindowPosition(win_orgX, win_orgY);
        return my_window;
    }
    public static void setWindowPosition(int orgX, int orgY){
        if(glfwWindow > 0){
            glfwSetWindowPos(glfwWindow, orgX, orgY);
        }
    }
    protected static void setWinWidth(int win_width, int win_height){
        AUWindowManager.win_width = win_width;
        AUWindowManager.win_height = win_height;
    }
    private static void initGlfwWindow(){
        glfwSetErrorCallback(errorCallback =
                GLFWErrorCallback.createPrint(System.err));
        if (!glfwInit())
            throw new IllegalStateException("Unable to initialize GLFW");
        glfwDefaultWindowHints();
        glfwWindowHint(GLFW_VISIBLE, GLFW_FALSE);
        glfwWindowHint(GLFW_RESIZABLE, GLFW_TRUE);
        glfwWindowHint(GLFW_SAMPLES, 8);
        //GLFW.glfwWindowHint(GLFW.GLFW_DECORATED, org.lwjgl.glfw.GLFW.GLFW_FALSE);

        glfwWindow = glfwCreateWindow(win_width, win_height, "CSC 133", NULL, NULL);
        if (glfwWindow == NULL)
            throw new RuntimeException("Failed to create the GLFW window");
        glfwSetKeyCallback(glfwWindow, keyCallback = new GLFWKeyCallback() {
            @Override
            public void invoke(long window, int key, int scancode, int action, int
                    mods) {
                if (key == GLFW_KEY_ESCAPE && action == GLFW_RELEASE)
                    glfwSetWindowShouldClose(window, true);
            }
        });
        glfwSetFramebufferSizeCallback(glfwWindow, fbCallback = new
                GLFWFramebufferSizeCallback() {
                    @Override
                    public void invoke(long window, int w, int h) {
                        if (w > 0 && h > 0) {
                            win_width = w;
                            win_height = h;
                        }
                    }
                });
        GLFWVidMode vidmode = glfwGetVideoMode(glfwGetPrimaryMonitor());
        glfwSetWindowPos(glfwWindow, win_orgX, win_orgY);
        glfwMakeContextCurrent(glfwWindow);
        int VSYNC_INTERVAL = 1;
        glfwSwapInterval(VSYNC_INTERVAL);
        glfwShowWindow(glfwWindow);
    }
    public void updateContextToThis(){
        glfwMakeContextCurrent(glfwWindow);
    }
    public void destroyGlfwWindow(){
        glfwDestroyWindow(glfwWindow);
    }
    public boolean isGlfwWindowClosed(){
        return glfwWindowShouldClose(glfwWindow);
    }
    public void enableResizeWindowCallback(){
        glfwSetFramebufferSizeCallback(glfwWindow, resizeWindow);
    }
    public void swapBuffers(){
        glfwSwapBuffers(glfwWindow);
    }
    public int[] getWindowSize(){
        return new int[]{win_width, win_height};
    }

}
