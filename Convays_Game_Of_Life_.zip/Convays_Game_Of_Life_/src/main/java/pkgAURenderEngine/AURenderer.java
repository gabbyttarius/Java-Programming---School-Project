package pkgAURenderEngine;

import org.joml.Matrix4f;
import org.lwjgl.BufferUtils;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL15;
import pkgAUUtils.AUGoLArray;
import pkgAUUtils.AUWindowManager;

import java.nio.FloatBuffer;
import java.nio.IntBuffer;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL20.glGetUniformLocation;

public class AURenderer {
    private AUGoLArray goLArray;
    private AUGeometryManager myGM;
    private AUWindowManager myWM;
    private int DRAW_MODE = GL_STATIC_DRAW;
    private final static int LIVE = 1;
    private final static int OGL_MATRIX_SIZE = 16;
    private final static int VPT = 4;
    private final static int EPT = 6;
    private final static int FPV = 2;
    private int vpMatLocation = 0;
    private int renderColorLocation = 0;
    public AURenderer(AUWindowManager myWM){
        winWidthHeight = myWM.getWindowSize();
        this.myWM = myWM;
    }
    public AURenderer(AUWindowManager myWM, AUGoLArray goLArray){
        winWidthHeight = myWM.getWindowSize();
        this.myWM = myWM;
        this.goLArray = goLArray;
        DRAW_MODE = GL_DYNAMIC_DRAW;
    }
    private int shader_program;
    private int size;
    private int numRows;
    private int numCols;
    private int padding;
    private int offset;
    private int[] winWidthHeight;
    Matrix4f viewProjMatrix = new Matrix4f();
    FloatBuffer myFloatBuffer = BufferUtils.createFloatBuffer(OGL_MATRIX_SIZE);
    private final int SLEEP_INTERVAL = 200;

    /*
    public void render(final int offset, final int padding, final int size, final int numRows, final int numCols){
        updateFields(offset, padding, size, numRows, numCols);
        AUGoLArray goLArray = new AUGoLArray(numRows, numCols);
        goLArray.swapLiveAndNext();
        for(int row = 0; row < numRows; row++){
            for(int col = 0; col < numCols; col++){
                goLArray.setCell(row, col, LIVE);
            }
        }
        goLArray.swapLiveAndNext();

        renderLoop(goLArray, GL15.GL_STATIC_DRAW);
        myWM.destroyGlfwWindow();
        goLArray.printArray();
    }
    */
    public void render(final int offset, final int padding, final int size, final int numRows, final int numCols){
        if(DRAW_MODE == GL_STATIC_DRAW){
            this.goLArray = new AUGoLArray(numRows, numCols);
            this.goLArray.swapLiveAndNext();
            for(int row = 0; row < numRows; row++){
                for(int col = 0; col < numCols; col++){
                    goLArray.setCell(row, col, LIVE);
                }
            }
            goLArray.swapLiveAndNext();

        }
        updateFields(offset, padding, size, numRows, numCols);
        renderLoop();
        myWM.destroyGlfwWindow();
    }

    private void updateFields(final int offset, final int padding, final int size, final int numRows, final int numCols){
        this.offset = offset;
        this.padding = padding;
        this.size = size;
        this.numRows = numRows;
        this.numCols = numCols;
        myWM.updateContextToThis();
        myGM = new AUGeometryManager(numRows, numCols, offset, size, padding, winWidthHeight);
    }

    /*
    private void renderLoop(){
        glfwPollEvents();
        initOpenGL();
        renderObjects();
        //Process window messages in the main thread
        while (!myWM.isGlfwWindowClosed()) {
            glfwWaitEvents();
        }
    }
    */
    private void renderLoop(){
        glfwPollEvents();
        initOpenGL();
        renderObjects();
        /* Process window messages in the main thread */
        while (!myWM.isGlfwWindowClosed()) {
            glfwWaitEvents();
        }
    }
    private void renderObjects(){
        while(!myWM.isGlfwWindowClosed()){
            glfwPollEvents();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            int vbo = glGenBuffers();
            int ibo = glGenBuffers();
            /*
            float[] vertices = generateTilesVertices(numRows, numCols);
            int[] indices = generateTileIndices(numRows, numCols);
            */
            /*
            float[] vertices = myGM.my_generateTileVertices(goLArray);
             */
            int numberOfAliveCells = myGM.character_counter(LIVE, goLArray.getArray());
            float[] vertices = new float[numberOfAliveCells * VPT * FPV];
            myGM.generateTilesVertices(goLArray, vertices);

            int[] indices = myGM.generateTileIndices(numberOfAliveCells);
            if(DRAW_MODE == GL_DYNAMIC_DRAW) {
                goLArray.onTickUpdate();
                goLArray.swapLiveAndNext();
            }
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            glBufferData(GL_ARRAY_BUFFER, (FloatBuffer) BufferUtils.
                    createFloatBuffer(vertices.length).
                    put(vertices).flip(), DRAW_MODE);

            glEnableClientState(GL_VERTEX_ARRAY);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER, (IntBuffer) BufferUtils.
                    createIntBuffer(indices.length).
                    put(indices).flip(), DRAW_MODE);
            glVertexPointer(2, GL_FLOAT, 0, 0L);
            viewProjMatrix.setOrtho(0, winWidthHeight[0], 0, winWidthHeight[1], 0, 10);
            glUniformMatrix4fv(vpMatLocation, false,
                    viewProjMatrix.get(myFloatBuffer));// switched the interface method of creation of float
            //buffer probably to update the myFloatBuffer(from OGL_MATRIX_SIZE to vertices.length) to
            //be reused in the immediate above line. Note: we don't a variable to store IntBuffer
            glUniform3f(renderColorLocation, 1.0f, 0.498f, 0.153f);
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            glDrawElements(GL_TRIANGLES, indices.length, GL_UNSIGNED_INT, 0L);
            if (SLEEP_INTERVAL > 0) {
                try {
                    Thread.sleep(SLEEP_INTERVAL);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            myWM.swapBuffers();//glfwSwapBuffers(window);
        }
    }
    /*
    private void renderObjects(){
        while(!myWM.isGlfwWindowClosed()){
            glfwPollEvents();
            glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
            int vbo = glGenBuffers();
            int ibo = glGenBuffers();
            float[] vertices = generateTilesVertices(numRows, numCols);
            int[] indices = generateTileIndices(numRows, numCols);
            glBindBuffer(GL_ARRAY_BUFFER, vbo);
            glBufferData(GL_ARRAY_BUFFER, (FloatBuffer) BufferUtils.
                    createFloatBuffer(vertices.length).
                    put(vertices).flip(), GL_DYNAMIC_DRAW);

            glEnableClientState(GL_VERTEX_ARRAY);
            glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
            glBufferData(GL_ELEMENT_ARRAY_BUFFER, (IntBuffer) BufferUtils.
                    createIntBuffer(indices.length).
                    put(indices).flip(), GL_DYNAMIC_DRAW);
            glVertexPointer(2, GL_FLOAT, 0, 0L);
            viewProjMatrix.setOrtho(0, winWidthHeight[0], 0, winWidthHeight[1], 0, 10);
            glUniformMatrix4fv(vpMatLocation, false,
                    viewProjMatrix.get(myFloatBuffer));
            glUniform3f(renderColorLocation, 1.0f, 0.498f, 0.153f);
            glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
            glDrawElements(GL_TRIANGLES, indices.length, GL_UNSIGNED_INT, 0L);
            myWM.swapBuffers();//glfwSwapBuffers(window);
        }
    }
     */
    private float[] generateTilesVertices(final int rowTiles, final int colTiles){
        float[] myVertices = new float[VPT * FPV * numRows * numCols];
        int xmin, ymin, myIndex;
        for(int row = 0; row < rowTiles; row++){
            for(int col = 0; col < colTiles; col++){
                myIndex = (row*colTiles+col)*VPT*FPV;
                xmin = offset+(size+padding)*col;
                ymin = winWidthHeight[1] - (offset+size+(size+padding)*row);
                myVertices[myIndex] = xmin;
                myVertices[myIndex + 1] = ymin;
                myVertices[myIndex + 2] = xmin + size;
                myVertices[myIndex + 3] = ymin;
                myVertices[myIndex + 4] = xmin + size;
                myVertices[myIndex + 5] = ymin + size;
                myVertices[myIndex + 6] = xmin;
                myVertices[myIndex + 7] = ymin + size;
            }
        }
        return myVertices;
    }
    private int[] generateTileIndices(final int rows, final int cols){
        int[] myIndices = new int[EPT * numRows * numCols];
        int startIV, tileNum, startIndex;
        for(int row = 0; row < rows; row++){
            for(int col = 0; col < cols; col++){
                tileNum = (row*cols+col);
                startIndex = tileNum * EPT;
                startIV = tileNum * VPT;
                myIndices[startIndex] = startIV;
                myIndices[startIndex + 1] = startIV + 1;
                myIndices[startIndex + 2] = startIV + 2;
                myIndices[startIndex + 3] = startIV;
                myIndices[startIndex + 4] = startIV + 2;
                myIndices[startIndex + 5] = startIV + 3;
            }
        }
        return myIndices;
    }
    private void initOpenGL(){
        GL.createCapabilities();
        glEnable(GL_DEPTH_TEST);
        glEnable(GL_CULL_FACE);
        glViewport(0, 0, winWidthHeight[0], winWidthHeight[1]);//glViewport(0, 0, WIN_WIDTH, WIN_HEIGHT);
        glClearColor(0.0f, 0.0f, 1.0f, 1.0f);
        this.shader_program = glCreateProgram();
        int vs = glCreateShader(GL_VERTEX_SHADER);
        glShaderSource(vs,
                "uniform mat4 viewProjMatrix;" +
                        "void main(void) {" +
                        " gl_Position = viewProjMatrix * gl_Vertex;" +
                        "}");
        glCompileShader(vs);
        glAttachShader(shader_program, vs);
        int fs = glCreateShader(GL_FRAGMENT_SHADER);
        glShaderSource(fs,
                "uniform vec3 color;" +
                        "void main(void) {" +
                        " gl_FragColor = vec4(0.6f, 0.7f, 0.1f, 1.0f);" +
                        "}");
        glCompileShader(fs);
        glAttachShader(shader_program, fs);
        glLinkProgram(shader_program);
        glUseProgram(shader_program);
        vpMatLocation = glGetUniformLocation(shader_program, "viewProjMatrix");
    }
}
