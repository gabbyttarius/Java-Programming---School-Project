package pkgAURenderEngine;

import pkgAUUtils.AUGoLArray;
import pkgAUUtils.AUPingPongArray;
class AUGeometryManager{
    private final int VPT = 4;
    private final int EPT = 6;
    private final int FPV = 2;
    private static final int DEAD = 0, LIVE = 1;
    private AUPingPongArray myPPArray;
    private int numCols;
    private int numRows;
    private int total_prims;
    private int padding;
    private int size;
    private int[] winWidthHeight;
    private int offset;
    protected AUGeometryManager(final int maxRows, final int maxCols, final int offset, final int size, final int padding, int[] winwidthHeight){
        this.numRows = maxRows;
        this.numCols = maxCols;
        this.offset = offset;
        this.size = size;
        this.padding = padding;
        this.winWidthHeight = winwidthHeight;
    }
    protected int character_counter(final int number, final int[][] array){
        int counter = 0;
        for(int row = 0; row < array.length; row++){
            for(int col = 0; col < array[0].length; col++){
                if(number == array[row][col]){
                    counter++;
                }
            }
        }
        return counter;
    }
    protected float[] my_generateTileVertices(AUGoLArray goLArray){
        int[][] array = goLArray.getArray();
        int numberOfAliveCells = character_counter(LIVE, array);
        float[] liveArrayVertices = new float[numberOfAliveCells * VPT * FPV];
        int counter = 0, myStartIndex = 0;
        int xmin = 0, ymin = 0;
        for(int row = 0; row < array.length; row++){
            for(int col = 0; col < array[0].length; col++){
                if(array[row][col] == LIVE){
                    myStartIndex = VPT * FPV * counter;
                    xmin = offset+(size+padding)*col;
                    ymin = winWidthHeight[1] - (offset+size+(size+padding)*row);
                    fillArrayWithTileVertices(liveArrayVertices, myStartIndex, xmin, ymin);
                    counter++;
                }
            }
        }
        return liveArrayVertices;
    }
    protected int[] my_generateTileIndices(int numberOfTiles){
        int[] myIndices = new int[numberOfTiles * EPT];
        int startIV, tileNum, startIndex;
        for(int counter = 0; counter < numberOfTiles; counter++){
                startIndex = counter * EPT;
                startIV = counter * VPT;
                myIndices[startIndex] = startIV;
                myIndices[startIndex + 1] = startIV + 1;
                myIndices[startIndex + 2] = startIV + 2;
                myIndices[startIndex + 3] = startIV;
                myIndices[startIndex + 4] = startIV + 2;
                myIndices[startIndex + 5] = startIV + 3;
        }
        return myIndices;
    }
    protected float[] generateTileVertices(final int rowTiles, final int colTiles){
        float[] result = new float[rowTiles*colTiles];
        return result;
    }
    protected boolean fillArrayWithTileVertices(float[] vertices, final int startIndex, final float xmin, final float ymin){
        boolean result = false;
        vertices[startIndex] = xmin;
        vertices[startIndex + 1] = ymin;
        vertices[startIndex + 2] = xmin + size;
        vertices[startIndex + 3] = ymin;
        vertices[startIndex + 4] = xmin + size;
        vertices[startIndex + 5] = ymin + size;
        vertices[startIndex + 6] = xmin;
        vertices[startIndex + 7] = ymin + size;
        return result;
    }
    protected int[] generateTileIndices(final int totalTiles){
        int[] myIndices = new int[EPT * numRows * numCols];
        int startIV, tileNum, startIndex;
        for(int row = 0; row < numRows; row++){
            for(int col = 0; col < numCols; col++){
                tileNum = (row*numCols+col);
                startIndex = tileNum * EPT;
                startIV = tileNum * VPT;
                myIndices[startIndex] = startIV;
                myIndices[startIndex + 1] = startIV + 1;
                myIndices[startIndex + 2] = startIV + 2;
                myIndices[startIndex + 3] = startIV;
                myIndices[startIndex + 4] = startIV + 2;
                myIndices[startIndex + 5] = startIV + 3;
            }
        }
        return myIndices;
    }
    protected boolean generateTilesVertices(final AUGoLArray goLArray, float[] liveArrayVertices){
        boolean result = false;
        int[][] array = goLArray.getArray();
        int counter = 0, myStartIndex, xmin, ymin;
        for(int row = 0; row < array.length; row++){
            for(int col = 0; col < array[0].length; col++){
                if(array[row][col] == LIVE){
                    myStartIndex = VPT * FPV * counter;//counter = (row*numCols+col)
                    xmin = offset+(size+padding)*col;
                    ymin = winWidthHeight[1] - (offset+size+(size+padding)*row);
                    fillArrayWithTileVertices(liveArrayVertices, myStartIndex, xmin, ymin);
                    counter++;
                }
            }
        }
        return result;
    }
}
