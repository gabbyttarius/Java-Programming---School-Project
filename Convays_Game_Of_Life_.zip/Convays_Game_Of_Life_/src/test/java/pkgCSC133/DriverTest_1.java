package pkgCSC133;

import pkgAUUtils.AUGoLArray;
import pkgAUUtils.AUPingPongArray;

import static org.junit.jupiter.api.Assertions.*;

class DriverTest_1{
    private static int numRows = 16, numCols = 16, polyLength = 4, polyOffset = 10, polyPadding = 1;;
    private static final int MINIMUM_CYCLES = 5;
    private static boolean ULT_DEBUG = false;
    private static AUPingPongArray ppa_1 = new AUPingPongArray(7, 7, 0, 1);
    private static AUPingPongArray ppa_2 = new AUPingPongArray(7, 7, 0, 1);
    private static AUGoLArray golArray1 = new AUGoLArray(200, 200);
    private static AUGoLArray golArray2 = new AUGoLArray(200, 200);
    public static void main(String[] args) {
        ult_test_onTickUpdate();
        //previousTests();
    }
    private static boolean ult_test_onTickUpdate(){
        golArray1.swapLiveAndNext();
        golArray2.swapLiveAndNext();
        boolean retVal = false;
        golArray1.loadFile("gol_input_1.txt");
        golArray1.swapLiveAndNext();
        golArray1.onTickUpdate();
        golArray1.swapLiveAndNext();
        golArray2.loadFile("gol_input_1_2nd_iteration.txt");
        golArray2.swapLiveAndNext();
        if(areEqual(golArray1.getArray(), golArray2.getArray())){
            retVal = true;
        }
        debug("ult_a works");
        System.out.println("ult_a: " + (retVal ? "PASS" : "FAIL"));
        return retVal;
    }
    private static void previousTests(){
        ult_a();
        ult_b();
        ult_c();
        ult_d();
    }
    private static boolean ult_a(){
        ppa_1.swapLiveAndNext();
        ppa_2.swapLiveAndNext();
        boolean retVal = false;
        ppa_1.loadFile("ult_a_input.txt");
        ppa_1.swapLiveAndNext();
        ppa_2.loadFile("ult_a_verify.txt");
        ppa_2.swapLiveAndNext();
        complement(ppa_2);
        ppa_2.swapLiveAndNext();
        if(areEqual(ppa_1.getArray(), ppa_2.getArray())){
            retVal = true;
        }
        debug("ult_a works");
        System.out.println("ult_a: " + (retVal ? "PASS" : "FAIL"));
        return retVal;
    }

    private static boolean areEqual(int[][] liveArray1, int[][] liveArray2) {
        boolean result = true;
        if (liveArray1 == null || liveArray2 == null){
            return false;
        }

        if (liveArray1.length != liveArray2.length || liveArray1[0].length != liveArray2[0].length){
            return false;
        }

        for (int row = 0; row < liveArray1.length; row++) {
            for (int col = 0; col < liveArray1[0].length; col++) {
                if (liveArray1[row][col] != liveArray2[row][col]) {
                    return false; // Short-circuit on mismatch
                }
            }
        }
        return true; // Arrays are identical
    }

    private static boolean ult_b(){
        ppa_1.swapLiveAndNext();
        ppa_2.swapLiveAndNext();
        boolean retVal = true;
        debug("ult_b works");
        ppa_1.loadFile("ult_a_input.txt");
        ppa_1.swapLiveAndNext();
        ppa_2.loadFile("ult_a_verify.txt");
        ppa_2.swapLiveAndNext();
        int[][] liveArray1 = ppa_1.getArray();
        int[][] liveArray2 = ppa_2.getArray();
        for(int row = 0; row < liveArray1.length; row++){
            for(int col = 0; col < liveArray1[0].length; col++){
                if(liveArray1[row][col] == liveArray2[row][col]){
                    retVal = false;
                }
            }
        }
        System.out.println("ult_b: " + (retVal ? "PASS" : "FAIL"));
        return retVal;
    }
    private static void complement(AUPingPongArray ppa){
        int[][] liveArray = ppa.getArray();
        for(int row = 0; row < liveArray.length; row++){
            for(int col = 0; col < liveArray[0].length; col++){
                if(liveArray[row][col] == 0){
                    ppa.setCell(row, col, 1);
                }
                else{
                    ppa.setCell(row, col, 0);
                }
            }
        }
    }
    private static boolean ult_c(){
        ppa_1.swapLiveAndNext();
        ppa_2.swapLiveAndNext();
        boolean retVal = false;
        ppa_1 = new AUPingPongArray(7, 7, 0, 1);
        ppa_1.swapLiveAndNext();
        ppa_2 = new AUPingPongArray(7, 7, 0, 1);
        ppa_2.swapLiveAndNext();
        debug("ult_c works");
        ppa_1.loadFile("ult_a_input.txt");
        ppa_2.loadFile("ult_a_input.txt");
        ppa_2.swapLiveAndNext();
        boolean liveVsNextDifferent = !areEqual(ppa_2.getArray(), ppa_2.readFromNextArray());
        boolean liveEqualsSwappedNext = areEqual(ppa_2.getArray(), ppa_1.readFromNextArray());
        boolean nextEqualsSwappedLive = areEqual(ppa_2.readFromNextArray(), ppa_1.getArray());
        if (liveVsNextDifferent && liveEqualsSwappedNext && nextEqualsSwappedLive) {
            retVal = true;
        }
        System.out.println("ult_c: " + (retVal ? "PASS" : "FAIL"));
        return retVal;
    }
    private static boolean ult_d(){
        ppa_1.swapLiveAndNext();
        ppa_2.swapLiveAndNext();
        boolean retVal = false;
        if(ULT_DEBUG){
            System.out.println("Debugging Statements");
        }
        int counter;
        for(counter = 0; counter < MINIMUM_CYCLES; counter++){
            ppa_1.loadFile("ult_a_input.txt");
            ppa_2.loadFile("ult_a_input.txt");
            ppa_1.swapLiveAndNext();
            ppa_2.swapLiveAndNext();
            ppa_1.randomizeViaFisherYatesKnuth();
            ppa_1.swapLiveAndNext();
            ppa_2.swapLiveAndNext();
            if(areEqual(ppa_1.getArray(), ppa_2.getArray())){
                break;
            }
        }
        if(counter == MINIMUM_CYCLES){
            retVal = true;
        }
        System.out.println("ult_d: " + (retVal ? "PASS" : "FAIL"));
        return retVal;
    }
    private static void debug(String input){
        if(ULT_DEBUG) {
            System.out.println(input);
        }
    }
}