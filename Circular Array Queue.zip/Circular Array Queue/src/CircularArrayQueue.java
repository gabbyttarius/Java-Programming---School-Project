public class CircularArrayQueue {
    private char[] array; // holds the items
    private int front; // index of the first item
    private int back; // index after the last item
    private int size; // number of elements in the queue

    public CircularArrayQueue(int capacity) {
        array = new char[capacity];
        front = 0;
        back = 0;
        size = 0;
    }

    // Method to insert a new char x into the back index of the queue
    public void enqueue(char x) {
        if (size == array.length) {
            throw new IllegalStateException("Queue is full");
        }
        array[back] = x;
        back = (back + 1) % array.length;
        size++;
    }

    // Method to check if the queue is empty
    public boolean isEmpty() {
        return size == 0;
    }

    // Method to remove and return the front char of the queue
    public char dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        char result = array[front];
        front = (front + 1) % array.length;
        size--;
        return result;
    }

    // Optional: Method to check if the queue is full
    public boolean isFull() {
        return size == array.length;
    }

    // Optional: Method to get the current size of the queue
    public int size() {
        return size;
    }

    // Main method to test the queue
    public static void main(String[] args) {
        CircularArrayQueue queue = new CircularArrayQueue(10);

        // Testing enqueue and dequeue operations
        queue.enqueue('A');
        queue.enqueue('B');
        queue.enqueue('C');

        System.out.println(queue.dequeue()); // Output: A
        System.out.println(queue.dequeue()); // Output: B
        System.out.println(queue.dequeue()); // Output: C

        // Check if queue is empty
        System.out.println(queue.isEmpty()); // Output: true

        // Adding more elements
        queue.enqueue('D');
        queue.enqueue('E');
        System.out.println(queue.dequeue()); // Output: D
        System.out.println(queue.isEmpty()); // Output: false
    }
}