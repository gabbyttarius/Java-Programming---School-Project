import java.io.*;

public class TestClass {
    public static void main(String[] args) {
        try {
            // Reading input
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            // Read the size of the array
            int N = Integer.parseInt(br.readLine().trim());

            // Read the array elements
            String[] arrStr = br.readLine().trim().split(" ");
            int[] arr = new int[N];

            // Check if the number of elements matches the size of the array
            if (arrStr.length != N) {
                System.out.println("Error: Number of elements does not match the specified size.");
                return;
            }

            for (int i = 0; i < N; i++) {
                arr[i] = Integer.parseInt(arrStr[i]);
            }

            // Count inversions using merge sort
            long result = MergeSort.mergeSortAndCount(arr, 0, N - 1);

            // Output the result
            System.out.println(result);
        } catch (IOException e) {
            System.out.println("Error reading input: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error: Please ensure all inputs are valid integers.");
        } catch (Exception e) {
            System.out.println("An unexpected error occurred: " + e.getMessage());
        }
    }
}