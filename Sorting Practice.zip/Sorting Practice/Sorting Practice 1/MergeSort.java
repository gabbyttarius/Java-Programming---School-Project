class MergeSort {
    // Function to perform merge sort and count inversions
    public static long mergeSortAndCount(int[] arr, int left, int right) {
        long count = 0;

        if (left < right) {
            // Find the middle point
            int mid = (left + right) / 2;

            // Recursively sort the left and right halves and count inversions
            count += mergeSortAndCount(arr, left, mid);
            count += mergeSortAndCount(arr, mid + 1, right);

            // Merge the two halves and count cross inversions
            count += mergeAndCount(arr, left, mid, right);
        }

        return count;
    }

    // Function to merge two halves and count inversions
    public static long mergeAndCount(int[] arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;

        // Create temporary arrays to store the left and right halves
        int[] leftArr = new int[n1];
        int[] rightArr = new int[n2];

        for (int i = 0; i < n1; i++) {
            leftArr[i] = arr[left + i];
        }

        for (int i = 0; i < n2; i++) {
            rightArr[i] = arr[mid + 1 + i];
        }

        int i = 0, j = 0, k = left;
        long invCount = 0;

        // Merge the two halves while counting inversions
        while (i < n1 && j < n2) {
            if (leftArr[i] <= rightArr[j]) {
                arr[k] = leftArr[i];
                i++;
            } else {
                arr[k] = rightArr[j];
                invCount += (n1 - i);  // All remaining elements in leftArr are greater than rightArr[j]
                j++;
            }
            k++;
        }

        // Copy the remaining elements of leftArr, if any
        while (i < n1) {
            arr[k] = leftArr[i];
            i++;
            k++;
        }

        // Copy the remaining elements of rightArr, if any
        while (j < n2) {
            arr[k] = rightArr[j];
            j++;
            k++;
        }

        return invCount;
    }
}