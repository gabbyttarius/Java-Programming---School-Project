import java.io.*;
import java.util.*;
import java.util.stream.Collectors;
public class Solution {
    public static void main(String[] args) {
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(System.in));

            // Reading input size and elements
            int n = Integer.parseInt(bufferedReader.readLine().trim());
            List<Integer> arr = Arrays.stream(bufferedReader.readLine().trim().split(" "))
                    .map(Integer::parseInt)
                    .collect(Collectors.toList());

            // Calling QuickSort
            List<Integer> result = QuickSort.sort(arr);

            // Outputting result
            System.out.println(result.stream()
                    .map(Object::toString)
                    .collect(Collectors.joining(" ")));

            bufferedReader.close();
        } catch (IOException e) {
            System.err.println("Error reading input: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.err.println("Invalid input format: " + e.getMessage());
        }
    }
}