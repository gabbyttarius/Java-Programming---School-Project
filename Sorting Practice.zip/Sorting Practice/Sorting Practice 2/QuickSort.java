import java.util.*;

class QuickSort {
    /**
     * QuickSort function: Takes a list of integers and returns the sorted list.
     * @param arr Input List of integers
     * @return Sorted List of integers
     */
    public static List<Integer> sort(List<Integer> arr) {
        // Base Case
        if (arr.size() <= 1) return arr;

        // Choosing the pivot element
        int pivot = arr.get(0);

        // Partitioning into left and right lists
        List<Integer> left = new ArrayList<>();
        List<Integer> right = new ArrayList<>();

        for (int i = 1; i < arr.size(); i++) {
            if (arr.get(i) <= pivot) {
                left.add(arr.get(i));
            } else {
                right.add(arr.get(i));
            }
        }

        // Recursive sorting of partitions
        List<Integer> sortedLeft = sort(left);
        List<Integer> sortedRight = sort(right);

        // Merging sorted partitions and pivot
        List<Integer> result = new ArrayList<>();
        result.addAll(sortedLeft);
        result.add(pivot);
        result.addAll(sortedRight);

        return result;
    }
}
