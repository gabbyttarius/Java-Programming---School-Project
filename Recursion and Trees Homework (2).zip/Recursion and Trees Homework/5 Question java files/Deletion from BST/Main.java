//Deletion from the BST
public class Main {
    private static class Node {
        int data;
        Node left, right;

        public Node(int data) {
            this.data = data;
        }
    }

    private Node root;

    public Main() {
        root = null;
    }

    public void insert(int data) {
        root = insert(root, data);
    }

    private Node insert(Node root, int data) {
        if (root == null) {
            root = new Node(data);
            return root;
        }

        if (data < root.data) {
            if (root.left == null) {
                root.left = new Node(data);
            } else {
                root.left = insert(root.left, data);
            }
        } else {
            if (root.right == null) {
                root.right = new Node(data);
            } else {
                root.right = insert(root.right, data);
            }
        }
        return root;
    }

    public Node deleteNode(int key) {
        root = deleteNode(root, key);
        return root;
    }

    private Node deleteNode(Node root, int key) {
        if (root == null) {
            return null;
        }

        if (key < root.data) {
            root.left = deleteNode(root.left, key);
        } else if (key > root.data) {
            root.right = deleteNode(root.right, key);
        } else {
            if (root.left == null && root.right == null) {
                return null;
            } else if (root.left == null) {
                return root.right;
            } else if (root.right == null) {
                return root.left;
            } else {
                Node temp = root.right;
                while (temp.left != null) {
                    temp = temp.left;
                }
                root.data = temp.data;
                root.right = deleteNode(root.right, temp.data);
            }
        }
        return root;
    }

    public void printInorder() {
        printInorder(root);
    }

    private void printInorder(Node root) {
        if (root != null) {
            printInorder(root.left);
            System.out.print(root.data + " ");
            printInorder(root.right);
        }
    }

    public static void main(String[] args) {
        Main bst = new Main();

        // Create a sample BST
        bst.insert(15);
        bst.insert(10);
        bst.insert(20);
        bst.insert(8);
        bst.insert(12);
        bst.insert(25);

        // Print the original BST
        System.out.println("Original BST (inorder traversal):");
        bst.printInorder();

        // Delete key 25 from the BST
        bst.deleteNode(25);

        // Print the updated BST
        System.out.println("\nUpdated BST (inorder traversal):");
        bst.printInorder();

        // Delete key 15 from the BST
        bst.deleteNode(15);

        // Print the updated BST
        System.out.println("\nUpdated BST (inorder traversal):");
        bst.printInorder();
    }
}
//The difference between the author and my solution is that the author had more consistency on its code
//because the author use a while loop accurately that the execution will only get executed until the certain
//node reach it's designated one. However, on my side of solution, I constructed a hard coding loop for
// shorter duration in order to execute the code deletion code properly. By looking at the author's code it
// had more conditioning than mine.
//