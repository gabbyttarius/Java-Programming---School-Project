//Search key in BST
public class Main {
    private static class Node {
        int data;
        Node left, right;

        public Node(int data) {
            this.data = data;
        }
    }

    private Node root;

    public Main() {
        root = null;
    }

    public void insert(int data) {
        root = insert(root, data);
    }

    private Node insert(Node root, int data) {
        if (root == null) {
            root = new Node(data);
            return root;
        }

        if (data < root.data) {
            if (root.left == null) {
                root.left = new Node(data);
            } else {
                root.left = insert(root.left, data);
            }
        } else {
            if (root.right == null) {
                root.right = new Node(data);
            } else {
                root.right = insert(root.right, data);
            }
        }
        return root;
    }

    public boolean search(int key) {
        return search(root, key);
    }

    private boolean search(Node root, int key) {
        if (root == null) {
            return false;
        }

        if (key == root.data) {
            return true;
        }

        if (key < root.data) {
            return search(root.left, key);
        } else {
            return search(root.right, key);
        }
    }

    public static void main(String[] args) {
        Main bst = new Main();

        // Create a sample BST
        bst.insert(15);
        bst.insert(10);
        bst.insert(20);
        bst.insert(8);
        bst.insert(12);
        bst.insert(25);

        // Search for key 25 in the BST
        boolean found = bst.search(25);
        System.out.println("Key 25 found: " + found);

        // Search for key 5 in the BST
        found = bst.search(5);
        System.out.println("Key 5 found: " + found);
    }
}
//*Comparing solution with the author.
//in class node instead of hard coding by assigning null I leave the node by its field by default
//in the class main with mine and the author got similarities of how we executed our code through
//insertion and search methods. However instead I constructed the code in the main class same as the author
//I would have not hard coding the code if I suddenly change the search that I am trying to look for,
//such as that I use boolean to search a certain node, not like the author used a for loop for consistency.