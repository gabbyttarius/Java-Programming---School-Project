//Determine if it is BST
public class Main {
    private static class Node {
        int data;
        Node left, right;

        public Node(int data) {
            this.data = data;
        }
    }

    private Node root;

    public Main() {
        root = null;
    }

    public void constructTree(int data) {
        root = constructTree(root, data);
    }

    private Node constructTree(Node root, int data) {
        if (root == null) {
            root = new Node(data);
            return root;
        }

        if (data < root.data) {
            if (root.left == null) {
                root.left = new Node(data);
            } else {
                root.left = constructTree(root.left, data);
            }
        } else {
            if (root.right == null) {
                root.right = new Node(data);
            } else {
                root.right = constructTree(root.right, data);
            }
        }
        return root;
    }

    public boolean isBST() {
        return isBST(root, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }

    private boolean isBST(Node root, int min, int max) {
        // Base case: if the tree is empty, return true
        if (root == null) {
            return true;
        }

        // If the current node's value is not within the valid range, return false
        if (root.data <= min || root.data >= max) {
            return false;
        }

        // Recursively check the left and right subtrees
        return isBST(root.left, min, root.data) && isBST(root.right, root.data, max);
    }

    public void printInorder() {
        printInorder(root);
    }

    private void printInorder(Node root) {
        if (root != null) {
            printInorder(root.left);
            System.out.print(root.data + " ");
            printInorder(root.right);
        }
    }

    public static void main(String[] args) {
        // Create a sample binary tree
        Main binaryTree = new Main();
        binaryTree.constructTree(15);
        binaryTree.constructTree(10);
        binaryTree.constructTree(20);
        binaryTree.constructTree(8);
        binaryTree.constructTree(12);
        binaryTree.constructTree(16);
        binaryTree.constructTree(25);

        // Print the inorder traversal of the binary tree
        System.out.println("Inorder traversal of the binary tree:");
        binaryTree.printInorder();

        // Check if the binary tree is a BST
        boolean isBST = binaryTree.isBST();

        // Print the result
        System.out.println("\nIs the binary tree a BST? " + isBST);
    }
}
//the solution between me and the author was the same however we have constructed into a different terminology in our
//parameters. However, the author had a method function to determine whether a given binary tree is BST, but I constructed mine
//differently which is not included in my code because I did not know if yet to construct a code the way the author use the swap
//code during the determining if the tree is a BST. We also have different construction on how we execute our main method class