import java.util.ArrayList;
import java.util.NoSuchElementException;

public class MaxThreeHeap {
    // Internal storage for the heap
    private ArrayList<Integer> heap;

    // Constructor to initialize the heap
    public MaxThreeHeap() {
        this.heap = new ArrayList<>();
    }

    // Public method to insert a value into the heap
    public void insert(int value) {
        heap.add(value); // Add the new value
        bubbleUp(heap.size() - 1); // Restore the heap property
    }

    // Public method to remove and return the maximum value from the heap
    public int deleteMax() {
        if (heap.isEmpty()) {
            throw new NoSuchElementException("Heap is empty");
        }

        int maxValue = heap.get(0); // Store the maximum value
        int lastValue = heap.remove(heap.size() - 1); // Remove the last element

        if (!heap.isEmpty()) {
            heap.set(0, lastValue); // Replace root with the last element
            bubbleDown(0); // Restore the heap property
        }

        return maxValue; // Return the maximum value
    }

    // Private helper method to maintain heap property after insertion
    private void bubbleUp(int index) {
        while (index > 0) { // Continue until we reach the root
            int parentIndex = (index - 1) / 3; // Calculate parent index
            if (heap.get(index) > heap.get(parentIndex)) {
                swap(index, parentIndex); // Swap if the current value is greater
                index = parentIndex; // Move up to parent's index
            } else {
                break; // Exit if the heap property is satisfied
            }
        }
    }

    // Private helper method to maintain heap property after deletion
    private void bubbleDown(int index) {
        int largest = index;
        for (int i = 1; i <= 3; i++) { // Check each child
            int childIndex = 3 * index + i;
            if (childIndex < heap.size() && heap.get(childIndex) > heap.get(largest)) {
                largest = childIndex; // Update largest if a child is greater
            }
        }

        if (largest != index) { // If largest is not the current index, swap
            swap(index, largest);
            bubbleDown(largest); // Continue bubbling down
        }
    }

    // Private helper method to swap two elements in the heap
    private void swap(int i, int j) {
        int temp = heap.get(i);
        heap.set(i, heap.get(j));
        heap.set(j, temp);
    }
}
