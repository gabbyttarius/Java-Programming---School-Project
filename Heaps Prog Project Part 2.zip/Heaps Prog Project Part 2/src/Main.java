import java.util.NoSuchElementException;

public class Main {
    public static void main(String[] args) {
        MaxThreeHeap maxHeap = new MaxThreeHeap();

        // Insert elements into the heap
        maxHeap.insert(10);
        maxHeap.insert(20);
        maxHeap.insert(5);
        maxHeap.insert(15);
        maxHeap.insert(30);

        // Test DeleteMax
        System.out.println(maxHeap.deleteMax()); // Should print 30
        System.out.println(maxHeap.deleteMax()); // Should print 20
        System.out.println(maxHeap.deleteMax()); // Should print 15
        System.out.println(maxHeap.deleteMax()); // Should print 10
        System.out.println(maxHeap.deleteMax()); // Should print 5

        // Test underflow behavior
        try {
            System.out.println(maxHeap.deleteMax()); // Should throw exception
        } catch (NoSuchElementException e) {
            System.out.println(e.getMessage()); // "Heap is empty"
        }
    }
}