//The one I worked on is the insert key into the BST
public class BinarySearchTrees {
    private static class Node {
        int data;
        Node left, right;

        public Node(int data) {
            this.data = data;
        }
    }

    private Node root;

    public BinarySearchTrees() {
        root = null;
    }

    public void insert(int k) {
        root = insert(root, k);
    }

    private Node insert(Node root, int k) {
        if (root == null) {
            root = new Node(k);
            return root;
        }

        if (k < root.data) {
            if (root.left == null) {
                root.left = new Node(k);
            } else {
                root.left = insert(root.left, k);
            }
        } else {
            if (root.right == null) {
                root.right = new Node(k);
            } else {
                root.right = insert(root.right, k);
            }
        }
        return root;
    }

    public void printInorder() {
        printInorder(root);
    }

    private void printInorder(Node root) {
        if (root != null) {
            printInorder(root.left);
            System.out.print(root.data + " ");
            printInorder(root.right);
        }
    }

    public static void main(String[] args) {
        BinarySearchTrees bst = new BinarySearchTrees();

        // Create a sample BST
        bst.insert(15);
        bst.insert(10);
        bst.insert(20);
        bst.insert(8);
        bst.insert(12);
        bst.insert(25);

        // Print the original BST
        System.out.println("Original BST (inorder traversal):");
        bst.printInorder();

        // Insert a new node with key 16 into the BST
        bst.insert(16);

        // Print the updated BST
        System.out.println("\nUpdated BST (inorder traversal):");
        bst.printInorder();
    }
}
//*Comparing solution with my solution on the correct solution
//The difference between the author and mine was the main method that I have created was hard coding
//and while the author's code was not. instead inserting automatically into the array, I construct a code that
//has to be coded directly into the method. I constructed mine as the same as the author in class node, however
//instead putting all the code directly into the class main method I organize them into a certain class with
//putting the unused field into private. Also, I constructed a printOrder class to organize the final result of the tree. 