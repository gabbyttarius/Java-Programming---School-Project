import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter the number of food items: ");
        int n = sc.nextInt(); // Number of food items
        sc.nextLine(); // To consume the newline character

        if (n <= 0) {
            System.out.println("No food items entered.");
            return;
        }

        GuessTheFood game = new GuessTheFood();

        // Input the food items and their characteristics
        for (int i = 0; i < n; i++) {
            System.out.print("Enter food name: ");
            String foodName = sc.next();
            System.out.print("Enter number of characteristics: ");
            int k = sc.nextInt(); // Number of characteristics

            Set<String> characteristics = new HashSet<>();
            System.out.println("Enter characteristics:");
            for (int j = 0; j < k; j++) {
                characteristics.add(sc.next()); // Read each characteristic
            }

            game.addFoodItem(foodName, characteristics);
        }

        // Calculate the maximum number of "yes" questions
        int maxYesQuestions = game.calculateMaxYesQuestions();

        // Output the result
        System.out.println("Maximum number of common characteristics: " + maxYesQuestions);
    }
}