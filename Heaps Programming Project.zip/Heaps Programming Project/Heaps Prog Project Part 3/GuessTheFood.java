import java.util.*;

public class GuessTheFood {

    private Map<String, Set<String>> foodCharacteristics;
    private List<Set<String>> characteristicsList;

    public GuessTheFood() {
        foodCharacteristics = new HashMap<>();
        characteristicsList = new ArrayList<>();
    }

    public void addFoodItem(String foodName, Set<String> characteristics) {
        foodCharacteristics.put(foodName, characteristics);
        characteristicsList.add(characteristics);
    }

    public int calculateMaxYesQuestions() {
        int maxYes = 0;

        // Iterate over all pairs of food items to find common characteristics
        for (int i = 0; i < characteristicsList.size(); i++) {
            for (int j = i + 1; j < characteristicsList.size(); j++) {
                Set<String> commonCharacteristics = new HashSet<>(characteristicsList.get(i));
                commonCharacteristics.retainAll(characteristicsList.get(j));

                maxYes = Math.max(maxYes, commonCharacteristics.size());
            }
        }

        return maxYes;
    }
}