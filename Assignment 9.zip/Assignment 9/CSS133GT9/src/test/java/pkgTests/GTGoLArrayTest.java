package pkgTests;

import org.junit.jupiter.api.Test;
import pkgGTUtils.GTGoLArray;
import pkgGTUtils.GTGeometryManager;

import java.io.IOException;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.*;

public class GTGoLArrayTest {
    @Test
    void testDefaultDimensions() {
        GTGoLArray a = new GTGoLArray(120, 120);          // ≥100 × ≥100
        assertEquals(120, a.rows());
        assertEquals(120, a.cols());
    }

    @Test
    void testDefaultLiveDensity() {
        int rows = 100, cols = 100;
        GTGoLArray a = new GTGoLArray(rows, cols);
        int live = countLive(a);
        double pct = live / (double) (rows * cols);
        assertTrue(pct > 0.15 && pct < 0.25,
                "Live-cell density should be roughly 20 %");
    }

    @Test
    void testStillLifeBlock() {
        GTGoLArray a = new GTGoLArray(4, 4, 0);           // start empty
        setLive(a, 1, 1); setLive(a, 1, 2);
        setLive(a, 2, 1); setLive(a, 2, 2);               // 2×2 block
        a.step();                                         // one update
        assertAll(
                () -> assertTrue(a.isAlive(1, 1)),
                () -> assertTrue(a.isAlive(1, 2)),
                () -> assertTrue(a.isAlive(2, 1)),
                () -> assertTrue(a.isAlive(2, 2))
        );
    }

    @Test
    void testOscillatorBlinker() {
        GTGoLArray a = new GTGoLArray(5, 5, 0);
        setLive(a, 2, 1); setLive(a, 2, 2); setLive(a, 2, 3); // ───
        a.step();                                             // |
        assertAll(                                            //  |
                () -> assertTrue(a.isAlive(1, 2)),                //  ↓
                () -> assertTrue(a.isAlive(2, 2)),
                () -> assertTrue(a.isAlive(3, 2))
        );
    }

    @Test
    void testFileLoading() throws IOException {
        String file = Paths.get("gol_input_1.txt").toString();
        GTGoLArray a = new GTGoLArray(file);
        assertTrue(a.rows() > 0 && a.cols() > 0);
    }

    @Test
    void testGeometryVerticesCount() {
        GTGoLArray a = new GTGoLArray(10, 10);
        int live = countLive(a);
        GTGeometryManager g = new GTGeometryManager();
        float[] verts = g.verticesForLiveCells(a);
        assertEquals(live * 8, verts.length,
                "Each live cell should yield 8 floats (4 vertices)");
    }

    private static int countLive(GTGoLArray a) {
        int cnt = 0;
        for (int r = 0; r < a.rows(); ++r)
            for (int c = 0; c < a.cols(); ++c)
                if (a.isAlive(r, c)) ++cnt;
        return cnt;
    }

    /** Directly flips a cell to LIVE via reflection (tests only). */
    private static void setLive(GTGoLArray a, int r, int c) {
        try {
            var f = a.getClass().getSuperclass()          // GTPingPongArray
                    .getDeclaredField("liveArray");
            f.setAccessible(true);
            int[][] arr = (int[][]) f.get(a);
            arr[r][c] = GTGoLArray.LIVE;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
