package pkgCSC133;


import pkgGTUtils.GTWindowManager;
import pkgGTRenderEngine.GTRenderer;

public class Driver {
    public static void main(String[] args) {
        final int numRows = 6, numCols = 7, polyLength = 50, polyOffset = 10, polyPadding = 20;
        final int winWidth = (polyLength + polyPadding) * numCols + 2 * polyOffset;
        final int winHeight = (polyLength + polyPadding) * numRows + 2 * polyOffset;
        final int winOrgX = 50, winOrgY = 80;

        // Use GTWindowManager and GTRenderer
        final GTWindowManager myWM = GTWindowManager.get(winWidth, winHeight, winOrgX, winOrgY, "CSC133 Renderer");
        final GTRenderer myRenderer = new GTRenderer(myWM);

        myRenderer.render(polyOffset, polyPadding, polyLength, numRows, numCols);
        myRenderer.renderLoop(); // Now this works because renderLoop() is public
    }
}