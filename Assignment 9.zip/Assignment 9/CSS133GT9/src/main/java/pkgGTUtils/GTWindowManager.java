package pkgGTUtils;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.glfw.GLFWFramebufferSizeCallback;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.system.MemoryUtil;

public class GTWindowManager {
    // Singleton instance of the window manager
    private static GTWindowManager my_window;

    // GLFW window handle (long data type to store memory reference)
    private long glfwWindow;

    // Window width and height
    private int win_width, win_height;

    private GTWindowManager(int width, int height, int posX, int posY, String title) {
        this.win_width = width;
        this.win_height = height;
        initGlfwWindow(width, height, posX, posY, title);
    }

    public static GTWindowManager get(int width, int height, int posX, int posY, String title) {
        if (my_window == null) {
            my_window = new GTWindowManager(width, height, posX, posY, title);
        }
        return my_window;
    }

    public static GTWindowManager get() {
        return my_window;
    }

    private void initGlfwWindow(int width, int height, int posX, int posY, String title) {
        // Step 1: Initialize GLFW
        if (!GLFW.glfwInit()) {
            throw new IllegalStateException("Unable to initialize GLFW");
        }
        // Step 2: Create a window with given dimensions
        glfwWindow = GLFW.glfwCreateWindow(width, height, title, MemoryUtil.NULL, MemoryUtil.NULL);

        if (glfwWindow == MemoryUtil.NULL) {
            throw new RuntimeException("Failed to create GLFW window");
        }

        // Step 3: Set OpenGL context for this window
        GLFW.glfwMakeContextCurrent(glfwWindow);
        GL.createCapabilities();

        // Step 4: Set a callback function to handle window resizing
        GLFW.glfwSetFramebufferSizeCallback(glfwWindow, new GLFWFramebufferSizeCallback() {
            @Override
            public void invoke(long window, int width, int height) {
                win_width = width;
                win_height = height;
                GL11.glViewport(0, 0, width, height);
            }
        });

        // Step 5: Display the window
        GLFW.glfwShowWindow(glfwWindow);
    }

    public void updateContextToThis() {
        GLFW.glfwMakeContextCurrent(glfwWindow);
    }

    public void destroyGlfwWindow() {
        GLFW.glfwDestroyWindow(glfwWindow);
        GLFW.glfwTerminate();
    }

    public boolean isGlfwWindowClosed() {
        return GLFW.glfwWindowShouldClose(glfwWindow);
    }

    public void setWindowSize(int width, int height) {
        this.win_width = width;
        this.win_height = height;
        GLFW.glfwSetWindowSize(glfwWindow, width, height);
    }

    public void swapBuffers() {
        GLFW.glfwSwapBuffers(glfwWindow);
    }

    public int[] getWindowSize() {
        return new int[]{win_width, win_height};
    }
}