package pkgGTUtils;

import java.io.IOException;

public class GTPingPongArrayLive extends GTPingPongArray {
    public static final int DEAD = 0;
    public static final int LIVE = 1;

    public GTPingPongArrayLive(int numRows, int numCols, int numLiveCells) {
        super(numRows, numCols, DEAD, LIVE + 1);
        initializeWithLiveCells(numLiveCells);
    }

    private void initializeWithLiveCells(int numLiveCells) {
        // Fill with DEAD cells
        for (int i = 0; i < getNumRows(); i++) {
            for (int j = 0; j < getNumCols(); j++) {
                setCell(i, j, DEAD);
            }
        }

        // Place LIVE cells randomly
        int cellsPlaced = 0;
        while (cellsPlaced < numLiveCells) {
            int row = getRandom().nextInt(getNumRows());
            int col = getRandom().nextInt(getNumCols());
            if (getCell(row, col) == DEAD) {
                setCell(row, col, LIVE);
                cellsPlaced++;
            }
        }
    }

    public int countLiveDegreeTwoNeighbors(int row, int col) {
        int count = 0;
        int rows = getNumRows();
        int cols = getNumCols();

        for (int i = -2; i <= 2; i++) {
            for (int j = -2; j <= 2; j++) {
                if (i == 0 && j == 0) continue;

                int neighborRow = (row + i + rows) % rows;
                int neighborCol = (col + j + cols) % cols;

                if (getCell(neighborRow, neighborCol) == LIVE) {
                    count++;
                }
            }
        }
        return count;
    }

    public static boolean ult_a() {
        try {
            GTPingPongArrayLive ppa1 = new GTPingPongArrayLive(5, 5, 5);
            ppa1.loadFile("ult_a_input.txt");

            GTPingPongArrayLive ppa2 = new GTPingPongArrayLive(5, 5, 5);
            ppa2.loadFile("ult_a_verify.txt");
            ppa2.swapLiveAndNext();

            for (int i = 0; i < ppa1.getNumRows(); i++) {
                for (int j = 0; j < ppa1.getNumCols(); j++) {
                    if (ppa1.getCell(i, j) != ppa2.getCell(i, j)) {
                        return false;
                    }
                }
            }
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static boolean ult_b() {
        GTPingPongArrayLive ppa = new GTPingPongArrayLive(5, 5, 0);

        for (int i = 0; i < ppa.getNumRows(); i++) {
            for (int j = 0; j < ppa.getNumCols(); j++) {
                if (ppa.getCell(i, j) != DEAD) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean ult_c() {
        GTPingPongArrayLive ppa = new GTPingPongArrayLive(5, 5, 5);

        int[][] original = new int[ppa.getNumRows()][ppa.getNumCols()];
        for (int i = 0; i < ppa.getNumRows(); i++) {
            for (int j = 0; j < ppa.getNumCols(); j++) {
                original[i][j] = ppa.getCell(i, j);
            }
        }

        ppa.swapLiveAndNext();

        for (int i = 0; i < ppa.getNumRows(); i++) {
            for (int j = 0; j < ppa.getNumCols(); j++) {
                if (ppa.getCell(i, j) != DEAD) {
                    return false;
                }
            }
        }

        ppa.swapLiveAndNext();
        for (int i = 0; i < ppa.getNumRows(); i++) {
            for (int j = 0; j < ppa.getNumCols(); j++) {
                if (ppa.getCell(i, j) != original[i][j]) {
                    return false;
                }
            }
        }

        return true;
    }

    public static boolean ult_d() {
        GTPingPongArrayLive ppa = new GTPingPongArrayLive(5, 5, 5);

        int[][] initial = new int[ppa.getNumRows()][ppa.getNumCols()];
        for (int i = 0; i < ppa.getNumRows(); i++) {
            for (int j = 0; j < ppa.getNumCols(); j++) {
                initial[i][j] = ppa.getCell(i, j);
            }
        }

        for (int cycle = 0; cycle < 5; cycle++) {
            ppa.randomize();

            boolean changed = false;
            for (int i = 0; i < ppa.getNumRows() && !changed; i++) {
                for (int j = 0; j < ppa.getNumCols() && !changed; j++) {
                    if (ppa.getCell(i, j) != initial[i][j]) {
                        changed = true;
                    }
                }
            }

            if (!changed) {
                return false;
            }

            for (int i = 0; i < ppa.getNumRows(); i++) {
                for (int j = 0; j < ppa.getNumCols(); j++) {
                    initial[i][j] = ppa.getCell(i, j);
                }
            }
        }

        return true;
    }

    public static void runAllTests() {
        System.out.println("ult_a: " + (ult_a() ? "PASS" : "FAIL"));
        System.out.println("ult_b: " + (ult_b() ? "PASS" : "FAIL"));
        System.out.println("ult_c: " + (ult_c() ? "PASS" : "FAIL"));
        System.out.println("ult_d: " + (ult_d() ? "PASS" : "FAIL"));
    }

    public static void main(String[] args) {
        runAllTests();

        final int ROWS = 7, COLS = 7, LIVE_CELLS = 10;
        GTPingPongArrayLive liveBoard = new GTPingPongArrayLive(ROWS, COLS, LIVE_CELLS);

        System.out.println("\nInitial Live Board:");
        liveBoard.printArray();

        System.out.println("\nLive neighbor counts for each cell:");
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                System.out.printf("%3d", liveBoard.countLiveDegreeTwoNeighbors(i, j));
            }
            System.out.println();
        }
    }
}