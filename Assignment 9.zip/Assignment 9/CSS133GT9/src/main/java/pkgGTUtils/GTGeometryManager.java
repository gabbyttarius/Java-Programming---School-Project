package pkgGTUtils;

import java.util.Arrays;

public class GTGeometryManager {

    /* ---------- compatibility overload (add this) ------------------- */
    public float[] verticesForLiveCells(GTGoLArray gol) {
        return verticesForLiveCells(gol, 0, 1, 0);   // neutral defaults
    }

    /* ---------- full version used by the renderer ------------------- */
    public float[] verticesForLiveCells(GTGoLArray gol,
                                        int offset, int size, int padding) {

        int rows = gol.rows(), cols = gol.cols();
        float[] tmp = new float[rows * cols * 8];   // worst case
        int idx = 0;

        for (int r = 0; r < rows; ++r) {
            for (int c = 0; c < cols; ++c) {
                if (!gol.isAlive(r, c)) continue;

                float x = offset + c * (size + padding);
                float y = offset + r * (size + padding);

                /* TL */ tmp[idx++] = x;         tmp[idx++] = y;
                /* TR */ tmp[idx++] = x + size;  tmp[idx++] = y;
                /* BR */ tmp[idx++] = x + size;  tmp[idx++] = y + size;
                /* BL */ tmp[idx++] = x;         tmp[idx++] = y + size;
            }
        }
        return (idx == tmp.length) ? tmp : Arrays.copyOf(tmp, idx);
    }
}
