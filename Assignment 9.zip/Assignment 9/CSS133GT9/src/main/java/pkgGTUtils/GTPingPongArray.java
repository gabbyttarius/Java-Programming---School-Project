package pkgGTUtils;

import java.io.*;
import java.util.*;

public class GTPingPongArray {
    protected int[][] liveArray;
    protected int[][] nextArray;
    protected int numRows;
    protected int numCols;
    protected int randMin;
    protected int randMax;
    protected Random random;

    public GTPingPongArray(int numRows, int numCols, int randMin, int randMax) {
        this.numRows = numRows;
        this.numCols = numCols;
        this.randMin = randMin;
        this.randMax = randMax;
        this.random = new Random();
        this.liveArray = new int[numRows][numCols];
        this.nextArray = new int[numRows][numCols];
        randomize();
    }

    public void swapLiveAndNext() {
        int[][] temp = liveArray;
        liveArray = nextArray;
        nextArray = temp;
    }

    public void setCell(int row, int col, int newValue) {
        liveArray[row][col] = newValue;
    }

    public int getCell(int row, int col) {
        return liveArray[row][col];
    }

    public void randomize() {
        for (int i = 0; i < numRows; i++) {
            for (int j = 0; j < numCols; j++) {
                liveArray[i][j] = random.nextInt(randMax - randMin) + randMin;
            }
        }
    }

    public void randomizeViaFisherYatesKnuth() {
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                liveArray[row][col] = col;
            }
        }

        for (int row = numRows - 1; row > 0; row--) {
            for (int col = numCols - 1; col > 0; col--) {
                int randRow = random.nextInt(row + 1);
                int randCol = random.nextInt(col + 1);

                int temp = liveArray[row][col];
                liveArray[row][col] = liveArray[randRow][randCol];
                liveArray[randRow][randCol] = temp;
            }
        }
    }

    public void updateToNearestNNSum() {
        for (int row = 0; row < numRows; row++) {
            for (int col = 0; col < numCols; col++) {
                int sum = 0;
                for (int i = -1; i <= 1; i++) {
                    for (int j = -1; j <= 1; j++) {
                        if (i == 0 && j == 0) continue;
                        int neighborRow = (row + i + numRows) % numRows;
                        int neighborCol = (col + j + numCols) % numCols;
                        sum += liveArray[neighborRow][neighborCol];
                    }
                }
                nextArray[row][col] = sum;
            }
        }
    }

    public void loadFile(String fileName) throws IOException {
        try (Scanner scanner = new Scanner(new File(fileName))) {
            int defaultValue = scanner.nextInt();
            int rows = scanner.nextInt();
            int cols = scanner.nextInt();

            int[][] newArray = new int[rows][cols];
            for (int[] row : newArray) {
                Arrays.fill(row, defaultValue);
            }

            while (scanner.hasNextInt()) {
                int rowIndex = scanner.nextInt();
                for (int col = 0; col < cols && scanner.hasNextInt(); col++) {
                    newArray[rowIndex][col] = scanner.nextInt();
                }
            }

            this.liveArray = newArray;
            this.nextArray = new int[rows][cols];
            this.numRows = rows;
            this.numCols = cols;
        }
    }

    public void save(String fileName) throws IOException {
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName))) {
            for (int[] row : liveArray) {
                for (int val : row) {
                    writer.print(val + " ");
                }
                writer.println();
            }
        }
    }

    public void printArray() {
        for (int[] row : liveArray) {
            for (int val : row) {
                System.out.printf("%4d", val);
            }
            System.out.println();
        }
    }

    // Helper getters for child class
    protected int getNumRows() { return numRows; }
    protected int getNumCols() { return numCols; }
    protected Random getRandom() { return random; }
}