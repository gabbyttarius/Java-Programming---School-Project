package pkgGTUtils;

import java.io.IOException;
import java.util.Arrays;
import java.util.Random;

public class GTGoLArray extends GTPingPongArray {

    /* ------------------------------------------------------------------ */
    public static final int DEAD = 0;
    public static final int LIVE = 1;
    private final Random random = new Random();

    /* ------------------------------------------------------------------ */
    /*                    Constructors                                    */
    /* ------------------------------------------------------------------ */

    /** ≥100 × 100 board with ~20 % live cells (Assignment-9 default). */
    public GTGoLArray(int rows, int cols) {
        this(rows, cols, Math.round(rows * cols * 0.2f));
    }

    /** Board with an explicit number of initial live cells. */
    public GTGoLArray(int rows, int cols, int numAlive) {
        super(rows, cols, DEAD, LIVE + 1);   // build ping-pong arrays
        zero();
        sprinkleRandomLiveCells(numAlive);
    }

    /** Build board by loading a text file (0 = live, 1 = dead in file). */
    public GTGoLArray(String dataFile) throws IOException {
        super(1, 1, DEAD, LIVE + 1);         // dummy size – real size set by load
        loadFile(dataFile);                  // provided by GTPingPongArray
        invertBits();                        // flip to our LIVE = 1, DEAD = 0
    }

    /* ------------------------------------------------------------------ */
    /*                    Public helpers                                  */
    /* ------------------------------------------------------------------ */

    public int     rows()                 { return numRows; }
    public int     cols()                 { return numCols; }
    public boolean isAlive(int r, int c)  { return liveArray[r][c] == LIVE; }

    /** Advance the Game-of-Life simulation by one generation. */
    public void step() {
        for (int r = 0; r < numRows; ++r) {
            for (int c = 0; c < numCols; ++c) {
                int n   = liveNeighbourCount(r, c);
                int cur = liveArray[r][c];
                nextArray[r][c] = (cur == LIVE)
                        ? ((n == 2 || n == 3) ? LIVE : DEAD)
                        : (n == 3 ? LIVE : DEAD);
            }
        }
        swapLiveAndNext();
    }

    /* ------------------------------------------------------------------ */
    /*                    Private helpers                                 */
    /* ------------------------------------------------------------------ */

    /** Set every cell to DEAD. */
    private void zero() {
        for (int[] row : liveArray) Arrays.fill(row, DEAD);
    }

    /** Randomly turn {@code need} dead cells into live ones. */
    private void sprinkleRandomLiveCells(int need) {
        while (need > 0) {
            int r = random.nextInt(numRows), c = random.nextInt(numCols);
            if (liveArray[r][c] == DEAD) { liveArray[r][c] = LIVE; --need; }
        }
    }

    /** Count live neighbours with wrap-around (“toroidal”) edges. */
    private int liveNeighbourCount(int r, int c) {
        int n = 0;
        for (int dr = -1; dr <= 1; ++dr)
            for (int dc = -1; dc <= 1; ++dc)
                if (dr != 0 || dc != 0)
                    n += liveArray[(r + dr + numRows) % numRows]
                            [(c + dc + numCols) % numCols];
        return n;
    }

    /** Input files mark live cells with 0 and dead with 1 – invert them. */
    private void invertBits() {
        for (int r = 0; r < numRows; ++r)
            for (int c = 0; c < numCols; ++c)
                liveArray[r][c] = (liveArray[r][c] == DEAD) ? LIVE : DEAD;
    }
}
