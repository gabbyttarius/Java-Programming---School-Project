package pkgGTRenderEngine;

import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import pkgGTUtils.GTGoLArray;
import pkgGTUtils.GTGeometryManager;
import pkgGTUtils.GTWindowManager;


public class GTRenderer {

    /* ------------------------------------------------------------ */
    private final GTWindowManager   wm;
    private final GTGoLArray        gol;
    private final GTGeometryManager geom = new GTGeometryManager();
    /* ------------------------------------------------------------ */

    /* ---------- constructors ------------------------------------ */
    public GTRenderer(GTWindowManager wm) {
        this(wm, new GTGoLArray(120, 120));      // ≥100×100, ~20 % live
    }
    public GTRenderer(GTWindowManager wm, GTGoLArray gol) {
        this.wm  = wm;
        this.gol = gol;
    }

    /* ---------- layout params supplied by Driver ---------------- */
    private int OFFSET, PADDING, SIZE;
    private int winW,  winH;

    /** Driver’s first call: store layout info and start the loop. */
    public void render(int offset, int padding, int size,
                       int rowsVisible, int colsVisible) {

        OFFSET  = offset;
        PADDING = padding;
        SIZE    = size;

        int[] s = wm.getWindowSize();
        winW = s[0];
        winH = s[1];

        initOpenGL();
        mainLoop();                       // blocks until window closed
    }

    /** Stub so Driver.java compiles unchanged. */
    public void renderLoop() { /* nothing to do here */ }

    /* ------------------------------------------------------------ */
    private void initOpenGL() {
        GL.createCapabilities();

        GL11.glMatrixMode(GL11.GL_PROJECTION);
        GL11.glLoadIdentity();
        GL11.glOrtho(0, winW, winH, 0, -1, 1);   // pixel coords
        GL11.glMatrixMode(GL11.GL_MODELVIEW);

        GL11.glClearColor(0.0f, 0.0f, 0.8f, 1.0f);   // blue background
    }

    private void mainLoop() {
        while (!wm.isGlfwWindowClosed()) {
            GL11.glClear(GL11.GL_COLOR_BUFFER_BIT);


            float[] verts = geom.verticesForLiveCells(gol, OFFSET, SIZE, PADDING);
            int quads = verts.length / 8;

            for (int q = 0, b = 0; q < quads; ++q, b += 8) {
                GL11.glBegin(GL11.GL_QUADS);
                GL11.glColor3f(1.0f, 0.55f, 0.0f);      // orange live cells
                GL11.glVertex2f(verts[b  ], verts[b+1]);
                GL11.glVertex2f(verts[b+2], verts[b+3]);
                GL11.glVertex2f(verts[b+4], verts[b+5]);
                GL11.glVertex2f(verts[b+6], verts[b+7]);
                GL11.glEnd();
            }

            wm.swapBuffers();
            GLFW.glfwPollEvents();


            gol.step();
        }
        wm.destroyGlfwWindow();
    }
}
