public class Main {
    public static void main(String[] args) {
        // Initialize a binary search tree
        BinarySearchTree bst = new BinarySearchTree();

        // Example insertion with duplicate values
        bst.insert(50);
        bst.insert(30);
        bst.insert(20);
        bst.insert(40);
        bst.insert(70);
        bst.insert(60);
        bst.insert(80);
        bst.insert(40); // Duplicate value

        // Perform in-order traversal
        System.out.println("Inorder traversal of the BST without recursion:");
        bst.inorderWithoutRecursion();

        // Check if a value is in the BST
        System.out.println("\nContains 40? " + bst.contains(40));
        System.out.println("Contains 100? " + bst.contains(100));

        // Sorting array using SortIntegers class
        SortIntegers sorter = new SortIntegers();
        int[] arr = {50, 30, 20, 40, 70, 60, 80, 40};
        System.out.println("\nSorting an array of integers using BST:");
        sorter.sortIntegerArray(arr);
    }
}