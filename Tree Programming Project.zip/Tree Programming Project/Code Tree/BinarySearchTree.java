import java.util.Stack;

public class BinarySearchTree {
    private Node root;

    // Constructor for an empty tree
    public BinarySearchTree() {
        root = null;
    }

    // Method to insert a new integer into the BST, allowing duplicates
    public void insert(int key) {
        root = insertRec(root, key);
    }

    // Recursive method to insert a new key in the BST
    private Node insertRec(Node root, int key) {
        // If the tree is empty, return a new node
        if (root == null) {
            root = new Node(key);
            return root;
        }

        // Otherwise, recur down the tree
        if (key < root.key) {
            root.left = insertRec(root.left, key);
        } else {
            // Duplicate values are allowed and go to the right subtree
            root.right = insertRec(root.right, key);
        }

        return root;
    }

    // Method to perform in-order traversal using a stack (no recursion)
    public void inorderWithoutRecursion() {
        if (root == null) {
            return;
        }

        Stack<Node> stack = new Stack<>();
        Node curr = root;

        // Traverse the tree
        while (curr != null || !stack.isEmpty()) {
            // Reach the leftmost node of the current node
            while (curr != null) {
                stack.push(curr);
                curr = curr.left;
            }

            // Current must be null at this point
            curr = stack.pop();
            System.out.print(curr.key + " ");

            // We have visited the node and its left subtree, now it's time for its right subtree
            curr = curr.right;
        }
    }

    // Method to check if a tree is empty
    public boolean isEmpty() {
        return root == null;
    }

    // Method to test if the tree contains a given value
    public boolean contains(int key) {
        return containsRec(root, key);
    }

    // Recursive function to search a key in the tree
    private boolean containsRec(Node root, int key) {
        // Base cases: root is null or key is present at root
        if (root == null) {
            return false;
        }
        if (root.key == key) {
            return true;
        }

        // Key is greater than root's key
        if (root.key < key) {
            return containsRec(root.right, key);
        }

        // Key is smaller than root's key
        return containsRec(root.left, key);
    }

    // Private Node class
    private static class Node {
        int key;
        Node left, right;

        public Node(int item) {
            key = item;
            left = right = null;
        }
    }
}

// Class to sort integers by inserting them into a BST
class SortIntegers {
    // Method to sort an array of integers using BST
    public int[] sortIntegerArray(int[] arr) {
        BinarySearchTree bst = new BinarySearchTree();

        // Insert all integers into the BST
        for (int value : arr) {
            bst.insert(value);
        }

        // Retrieve the sorted integers by performing an in-order traversal
        bst.inorderWithoutRecursion();
        return arr; // You can collect sorted values if required
    }
}